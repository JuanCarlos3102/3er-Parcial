/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package myrsi.servlets;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import mrysi.beans.EntidadDAO;
import mrysi.beans.Persona;

/**
 *
 * @author carlos
 */
@WebServlet("/InsertEntidad")
public class ServletEscuelas extends HttpServlet {
    private EntidadDAO entidadDAO = (EntidadDAO) new EntidadDAOImpl();

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        String nombre = request.getParameter("nombre");
        Persona entidad = new Persona(id, nombre);

        // Configurar la conexión a la base de datos
        String url = "jdbc:postgresql://localhost:5433/UNIVERSIDAD_1";
        String user = "USER";
        String password = "password";

        try {
            // Cargar el driver de PostgreSQL
            Class.forName("org.postgresql.Driver");
            
            // Establecer la conexión y ejecutar la inserción
            try (Connection conn = DriverManager.getConnection(url, user, password)) {
                // Preparar la declaración SQL para la inserción
                String sql = "INSERT INTO entidad (id, nombre) VALUES (?, ?)";
                try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                    pstmt.setInt(1, entidad.getId());
                    pstmt.setString(2, entidad.getNombre());

                    // Ejecutar la inserción
                    pstmt.executeUpdate();
                }
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }

        response.sendRedirect("index.jsp");
    }
}