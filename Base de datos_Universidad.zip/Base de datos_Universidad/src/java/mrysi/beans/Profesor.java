/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mrysi.beans;

/**
 *
 * @author OMEN
 */
public class Profesor {
    private int id_profesor;
    private int id_departamento;

    public int getId_profesor() {
        return id_profesor;
    }

    public int getId_departamento() {
        return id_departamento;
    }

    public void setId_profesor(int id_profesor) {
        this.id_profesor = id_profesor;
    }

    public void setId_departamento(int id_departamento) {
        this.id_departamento = id_departamento;
    }
    
}
