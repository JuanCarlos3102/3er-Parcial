/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mrysi.beans;

/**
 *
 * @author OMEN
 */
public class Curso_escolar {
    private int id;
    private int anyo_inicio;
    private int anyo_fin;

    public int getId() {
        return id;
    }

    public int getAnyo_inicio() {
        return anyo_inicio;
    }

    public int getAnyo_fin() {
        return anyo_fin;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setAnyo_inicio(int anyo_inicio) {
        this.anyo_inicio = anyo_inicio;
    }

    public void setAnyo_fin(int anyo_fin) {
        this.anyo_fin = anyo_fin;
    }
    
    
}
