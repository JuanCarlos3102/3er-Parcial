/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


package Clases;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


/**
 *
 * @author maxim
 */
public class DAOImp implements DAO<Grado>{
   
    private Connection conn;

    public DAOImp() {
        try {
            this.conn = Conexion.getConnection();
        } catch (SQLException e) {
        }
    }
    @Override
    public void insert(Grado dep) throws SQLException {
        conn = Conexion.getConnection();
        String insertQuery = "INSERT INTO Grado (nombre) VALUES (?)";
        PreparedStatement ps = conn.prepareStatement(insertQuery);
       
        ps.setString(1, dep.getNombre());
        
        ps.executeUpdate();
        
        conn.close();
    }

    @Override
    public void update(Grado entidad) throws SQLException {
        String updateQuery = "UPDATE Grado SET nombre = ? WHERE id = ?";
        PreparedStatement ps = conn.prepareStatement(updateQuery);
        ps.setString(1, entidad.getNombre());
        ps.setInt(2, entidad.getId());
        ps.executeUpdate();
    }

    @Override
    public void delete(int id) throws SQLException {
              String deleteQuery = "DELETE FROM Grado WHERE id = ?";
        PreparedStatement ps = conn.prepareStatement(deleteQuery);
        ps.setInt(1, id);
        ps.executeUpdate();
    }

     @Override
    public Grado read(int id) throws SQLException {
       String readQuery = "SELECT * FROM grado WHERE id = ?";
        PreparedStatement ps = conn.prepareStatement(readQuery);
        ps.setInt(1, id);
        ResultSet rs = ps.executeQuery();
        if (rs.next()) {
            return new Grado(rs.getInt("id"), rs.getString("nombre"));
        }
        return null;
    }

    @Override
    public List<Grado> readAll() throws SQLException {
        String readAllQuery = "SELECT * FROM universidad.grado";
        PreparedStatement ps = conn.prepareStatement(readAllQuery);
        ResultSet rs = ps.executeQuery();
        List<Grado> deps = new ArrayList<>();
        while (rs.next()) {
            deps.add(new Grado(rs.getInt("id"), rs.getString("nombre")));
        }
        return deps;
    }
}
